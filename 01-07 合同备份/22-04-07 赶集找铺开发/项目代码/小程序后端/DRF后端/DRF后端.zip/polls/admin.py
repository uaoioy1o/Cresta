from django.contrib import admin
from polls.models import *
# Register your models here.
# admin.site.register(Test)
admin.site.register(Tips)