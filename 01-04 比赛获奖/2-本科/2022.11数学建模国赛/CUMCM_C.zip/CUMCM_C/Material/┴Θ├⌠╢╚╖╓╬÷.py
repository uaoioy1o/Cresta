import joblib
import xgboost as xgb
from SALib.sample import saltelli
from SALib.analyze import sobol
from SALib.test_functions import Ishigami
import numpy as np
import math
import os
from SALib.plotting.bar import plot as barplot
import matplotlib.pyplot as plot
import pandas as pd

# set the configuration
problem = {
    'num_vars':13,
    'names': ['SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', 'Al2O3', 'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO','SO2'],
    'bounds': [[3.72, 96.77],
               [0.8, 9.72],
               [0.11, 14.52],
               [0.21, 8.7],
               [0.43, 2.73],
               [0.45, 14.34],
               [0.17, 6.07],
               [0.11, 10.57],
               [0.11, 70.27],
               [0, 35.45],
               [0.07, 14.13],
               [0.04, 1.12],
               [0.36, 15.95]]
}

# 样本生成
param_values = saltelli.sample(problem, 1024)
param_values = pd.DataFrame(param_values)
names = ['SiO2', 'Na2O', 'K2O', 'CaO', 'MgO', 'Al2O3', 'Fe2O3', 'CuO', 'PbO', 'BaO', 'P2O5', 'SrO','SO2']
param_values.columns = names

"""
# 运行q3模型
# 读取数据
model = xgb.Booster()
model.load_model("complex_model.json")

y = model.predict(xgb.DMatrix(param_values))
Si = sobol.analyze(problem, y, print_to_console=True)
print()

# 一阶灵敏度
print('S1:', Si['S1'])

# 二阶灵敏度
print("x1-x2:", Si['S2'][0, 1])
print("x1-x3:", Si['S2'][0, 2])
print("x2-x3:", Si['S2'][1, 2])

Si_df = Si.to_df()
barplot(Si_df[0])
plot.show()
"""

# 运行q2高钾模型
model = joblib.load("铅钡聚类模型.pkl")
y = model.predict(param_values)
Si = sobol.analyze(problem, y, print_to_console=True)
Si_df = Si.to_df()
barplot(Si_df[0])
plot.show()
