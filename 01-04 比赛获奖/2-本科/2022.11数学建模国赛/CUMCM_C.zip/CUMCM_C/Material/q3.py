import xgboost as xgb
import os
import pandas as pd

# load the data
model = xgb.Booster()
model.load_model("model.json")

path = os.path.join("datasets", "original.xlsx")
data = pd.read_excel(path, sheet_name="表单3")

data = data.drop(["文物编号"], axis=1)
data = data.drop(["PbO"], axis=1)
data = data.drop(["BaO"], axis=1)

# predict the outcome
x_test = xgb.DMatrix(data)
predict_result = model.predict(x_test)
print('predict_result', predict_result)
