import numpy as np
import pandas as pd


# 分割训练与验证集
def split_train_test(data, test_ratio=0.2):
    shuffled_indices = np.random.permutation(len(data))
    test_set_size = int(len(data) * test_ratio)
    test_indices = shuffled_indices[:test_set_size]
    train_indices = shuffled_indices[test_set_size:]

    train_set = data.iloc[train_indices]
    test_set = data.iloc[test_indices]
    y_train = train_set["biao_mian_feng_hua"]
    x_train = train_set.copy().drop(["biao_mian_feng_hua"], axis=1)

    y_test = test_set["biao_mian_feng_hua"]
    x_test = test_set.copy().drop(["biao_mian_feng_hua"], axis=1)

    return x_train, y_train, x_test, y_test
