import joblib
from sklearn.cluster import KMeans
import pandas as pd
import os
from sklearn import metrics


# load the data
path = os.path.join("datasets", "所有高钾风化前数据.xlsx")
data = pd.read_excel(path)
data = data.drop(["文物采样点"], axis=1)

data = data.fillna(data.mean())
data = data.drop(["氧化锡(SnO2)"], axis=1)


# show the outcome of qian_bei
model = KMeans(n_clusters=2, random_state=9)
model.fit(data)
pred = model.predict(data)
print(3)
print("silhouette score: ", metrics.silhouette_score(data, pred))
print("harabasz score: ", metrics.calinski_harabasz_score(data, pred))
print(pred)

joblib.dump(model, "高钾聚类模型.pkl")
"""    
model = KMeans(n_clusters=2, random_state=9)
model.fit(data)
pred = model.predict(data)
print(2, metrics.calinski_harabasz_score(data, pred))
"""

# pred数据中存储预测的结果
# print(pred)
