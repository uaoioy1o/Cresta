import pandas as pd
import os
import numpy as np

# load the data
path = os.path.join("datasets", "data.xlsx")
attachment1 = pd.read_excel(path)
data = attachment1.copy()


# calculate Cramér’s V coefficient
def calculate_caremers_v(df, column_a, column_b):
    """
    calculate carmer v for the 2 input columns in dataframe
    :param df: Pandas dataframe object
    :param column_a: 1st column to study
    :param column_b: 2nd column to study
    :return: Pandas dataframe object with the duplicated recorders removed.
    """
    if column_a not in df.columns:
        print("the input column %s doesn't exit in the dataframe." % column_a)
        return None
    elif column_b not in df.columns:
        print("the input column %s doesn't exit in the dataframe." % column_b)
        return None
    else:
        cross_tb = pd.crosstab(index=df[column_a], columns=df[column_b])
        np_tb = cross_tb.to_numpy()
        min_row_column = min(np_tb.shape[0], np_tb.shape[1])
        colume_sum = np_tb.sum(axis=0)
        row_sum = np_tb.sum(axis=1)
        total_sum = np_tb.sum()
        np_mid = np.matmul(row_sum.reshape(len(row_sum), 1),
                           colume_sum.reshape(1, len(colume_sum))) / total_sum
        new_tb = np.divide(np.power((np_tb - np_mid), np.array([2])),
                           np_mid)

        return new_tb.sum() / (total_sum * (min_row_column - 1))


print("Cramér’s V coefficient between lei_xing and result： ", calculate_caremers_v(data, "lei_xing", "you_wu_feng_hua"))
print("Cramér’s V coefficient between wen_shi and result： ", calculate_caremers_v(data, "wen_shi", "you_wu_feng_hua"))
print("Cramér’s V coefficient bwtween yan_se and the result： ", calculate_caremers_v(data, "yan_se", "you_wu_feng_hua"))


