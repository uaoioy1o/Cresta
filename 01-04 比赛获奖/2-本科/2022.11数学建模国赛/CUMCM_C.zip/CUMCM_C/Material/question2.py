import pandas as pd
import os


pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

path = os.path.join("datasets", "data2.xlsx")
real_data = pd.read_excel(path, sheet_name="高钾无风化")
data = real_data.copy()
data = data.drop(["文物采样点"], axis=1)
corr_matrix = data.corr()
corr_matrix.to_excel("高钾无风化.xlsx")

