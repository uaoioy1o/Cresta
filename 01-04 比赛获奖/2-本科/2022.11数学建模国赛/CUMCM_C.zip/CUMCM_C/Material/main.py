import os
import pandas as pd
import xgboost as xgb
from xgboost import XGBRegressor
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_validate
import utils.tools as tools
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold

# load the data
path = os.path.join("datasets", "original.xlsx")
data = pd.read_excel(path, sheet_name="表单2")
data = data.drop(["文物采样点"], axis=1)

"""
# 材质映射
material_mapping = {'高钾': 0, '铅钡': 1}
# 风化映射
result_mapping = {'无风化': 0, '风化': 1}
# 纹饰映射
ornament_mapping = {'A': 1, 'B': 2, 'C': 3}
# 颜色映射
color_mapping = {"蓝绿": 1, "浅蓝": 2, "紫": 3, "深绿": 4, "深蓝": 5, "浅绿": 6, "黑": 7, "绿": 8}

attachment1["lei_xing"] = attachment1["lei_xing"].map(material_mapping)
attachment1["biao_mian_feng_hua"] = attachment1["biao_mian_feng_hua"].map(result_mapping)
attachment1["wen_shi"] = attachment1["wen_shi"].map(ornament_mapping)
attachment1["yan_se"] = attachment1["yan_se"].map(color_mapping)

x_train, y_train, x_test, y_test = tools.split_train_test(attachment1, test_ratio=0.2)


# encapsulate the data with DMatrix
data_train = xgb.DMatrix(x_train, y_train, enable_categorical=True)
data_test = xgb.DMatrix(x_test, y_test, enable_categorical=True)

# 参数
param = {'max_depth': 3, 'eta': 0.2, 'verbosity': 1, 'objective': 'binary:logistic'}

raw_model = xgb.train(param, data_train, num_boost_round=50)

pred_train_raw = raw_model.predict(data_train)
for i in range(len(pred_train_raw)):
    if pred_train_raw[i] > 0.5:
        pred_train_raw[i] = 1
    else:
        pred_train_raw[i] = 0
print("训练集的正确率为: ", accuracy_score(data_train.get_label(), pred_train_raw))

pred_test_raw = raw_model.predict(data_test)
for i in range(len(pred_test_raw)):
    if pred_test_raw[i] > 0.5:
        pred_test_raw[i] = 1
    else:
        pred_test_raw[i] = 0
print("验证集的正确率为: ", accuracy_score(data_test.get_label(), pred_test_raw))

xgb.plotting.plot_tree(raw_model)
plt.show()
plt.savefig("./xxx.jpg")
"""


# decision tree
#data = data.drop(["PbO"], axis=1)
#data = data.drop(["BaO"], axis=1)

y_train = data["lei_xing"]
x_train = data.copy().drop(["lei_xing"], axis=1)

params = {'n_estimators': 400, 'booster': 'gbtree', 'max_depth': 5, 'learning_rate': 0.5, 'objective': 'binary:logistic',
          'subsample': 1, 'colsample_bytree': 1}
model = xgb.XGBRegressor(**params)

cv = KFold(n_splits=5, shuffle=True, random_state=100)
model.fit(x_train, y_train)
results = cross_val_score(model, x_train, y_train, cv=cv)
print("Accuracy: %.2f%%" % (results.mean()*100))

model.save_model("complex_model.json")

xgb.plotting.plot_tree(model)
plt.show()
plt.savefig("简化决策树.jpg")


"""
data = data.drop(["wen_wu_bian_hao"], axis=1)
# 只按表单一生成决策树
y_train = data["lei_bie"]
x_train = data.copy().drop(["lei_bie"], axis=1)

params = {'n_estimators': 400, 'booster': 'gbtree', 'max_depth': 4, 'learning_rate': 0.8, 'objective': 'binary:logistic',
          'subsample': 1, 'colsample_bytree': 1}
model = xgb.XGBRegressor(**params)

cv = KFold(n_splits=5, shuffle=True, random_state=100)
model.fit(x_train, y_train)
results = cross_val_score(model, x_train, y_train, cv=cv)
print("Accuracy: %.2f%%" % (results.mean()*100))

xgb.plotting.plot_tree(model)
plt.show()
plt.savefig("基于表1的决策树.jpg")
"""

"""
model = XGBRegressor(learning_rate=0.5, n_estimators=400, max_depth=6, objective= 'binary:logistic', subsample=1)
kfold = KFold(n_splits=5)
results = cross_val_score(model, x_train, y_train, cv=kfold)
print("Accuracy: %.2f%%" % (results.mean()*100))
"""

"""
# 参数
param = {'max_depth': 3, 'eta': 0.2, 'verbosity': 1, 'objective': 'binary:logistic'}

kfold = KFold(n_splits=5)
for train_index, test_index in kfold.split(x_train, y_train):
    # 本组训练集
    this_train_x, this_train_y = x_train.iloc[train_index], y_train.iloc[train_index]
    this_test_x, this_test_y = x_train.iloc[test_index], y_train.iloc[test_index]

    # 将数据用DMatrix封装
    data_train = xgb.DMatrix(this_train_x, this_train_y)
    data_test = xgb.DMatrix(this_test_x, this_test_y)

    model.fit()
"""