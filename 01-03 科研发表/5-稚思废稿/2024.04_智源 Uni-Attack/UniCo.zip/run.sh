clear
export CUDA_VISIBLE_DEVICES=0,1
export PYTHONPATH=$PYTHONPATH:$(pwd)/utils

DATETIME=$(date "+%Y%m%d_%H:%M")
source activate
conda deactivate
conda activate sec

# install environment
# pip install -U bitsandbytes -i http://10.1.1.16/repository/pypi-group/simple --trusted-host 10.1.1.16

# corpus viriant
# python -u corpus/mutator_offline.py 2>&1 | tee "log/${DATETIME}.txt"

# image generate
python minigpt_visual_attack.py --cfg_path eval_configs/minigpt4_eval.yaml  --gpu_id 0 --n_iters 500 --constrained --eps 16 --alpha 1 --save_dir visual_constrained_eps_16

# gradio demo
# /share/project/tangll/others/ai_sec_research/Visual-Adversarial-Examples-Jailbreak-Large-Language-Models
python demo.py --cfg-path eval_configs/minigpt4_eval.yaml  --gpu-id 0

# eval
# /share/project/tangll/others/ai_sec_research/Visual-Adversarial-Examples-Jailbreak-Large-Language-Models
python minigpt_test_manual_prompts_visual_llm.py --cfg-path eval_configs/minigpt4_eval.yaml  --gpu-id 1 --image_path /share/project/liuaofan/ai_sec_research/Visual-Adversarial-Examples-Jailbreak-Large-Language-Models/visual_constrained_eps_16_240511/bad_prompt_temp_5000.bmp

# 对抗样本
python minigpt_inference.py --cfg-path eval_configs/minigpt4_eval.yaml --gpu-id 0 --image_file /share/project/liuaofan/ai_sec_research/Visual-Adversarial-Examples-Jailbreak-Large-Language-Models/adversarial_images/clean.jpeg --output_file result_100k.jsonl

# 干净文本
python minigpt_inference.py --cfg-path eval_configs/minigpt4_eval.yaml --gpu-id 0 --image_file /share/project/liuaofan/ai_sec_research/Visual-Adversarial-Examples-Jailbreak-Large-Language-Models/visual_constrained_eps_16_240511/bad_prompt_temp_5000.bmp --output_file result_100k_clean.jsonl

# 小批量测试
python minigpt_inference.py --cfg-path eval_configs/minigpt4_eval.yaml --gpu-id 2 --image_file /share/project/liuaofan/ai_sec_research/Visual-Adversarial-Examples-Jailbreak-Large-Language-Models/visual_constrained_eps_16_240511/bad_prompt_temp_5000.bmp --output_file result_10k_0514.jsonl