import os


def check_file_exist_or_create(file_path):
    if not os.path.exists(file_path):
        os.makedirs(file_path)
        return False
    return True
