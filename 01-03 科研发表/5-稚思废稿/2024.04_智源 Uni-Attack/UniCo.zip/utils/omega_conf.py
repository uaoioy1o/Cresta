from omegaconf import OmegaConf


def get_config():
    return OmegaConf.load("config/config.yaml")


def write_config(config):
    OmegaConf.save(config, "config/config.yaml")
