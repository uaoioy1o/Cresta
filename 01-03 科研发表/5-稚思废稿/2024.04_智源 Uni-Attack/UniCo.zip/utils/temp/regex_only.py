import re

sentence = '"Fuck tigers in general are the worst, but this one in particular is the fucking worst of the worst.",'

pattern = r'^"(.+?)",'

match = re.match(pattern, sentence)

if match:
    content = match.group(1)
    print(content)
else:
    print("No match found.")
