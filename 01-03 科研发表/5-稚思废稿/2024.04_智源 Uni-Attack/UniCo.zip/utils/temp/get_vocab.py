from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("unsloth/llama-2-7b")

vocabs = tokenizer.get_vocab()

single_token_vocabs = []
single_token_vocabs_embedding = []
single_token_id_to_vocab = dict()
single_token_vocab_to_id = dict()

cnt = 0
for item in vocabs:
    print(item)
    tokens = tokenizer(item, return_tensors="pt", add_special_tokens=False).input_ids
    if tokens.shape[1] == 1:
        print(f"{cnt}: {item}")
