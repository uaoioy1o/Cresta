from sentence_transformers import SentenceTransformer, util
import torch

model = SentenceTransformer("all-MiniLM-L6-v2")


def get_similarity(text1, text2):
    embeddings1 = model.encode(text1, convert_to_tensor=True)
    embeddings2 = model.encode(text2, convert_to_tensor=True)

    similarity = util.pytorch_cos_sim(embeddings1, embeddings2)

    return similarity.item()


text1 = "I have a pen."
text2 = "I own a pen."

similarity_score = get_similarity(text1, text2)
print(f"The similarity score between the texts is: {similarity_score:.4f}")
