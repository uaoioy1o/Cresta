import random
from transformers import LlamaModel, LlamaTokenizer
import torch

# 初始化Llama2模型和tokenizer
model_name = "Llama/large"  # 根据实际需要选择合适的模型版本
tokenizer = LlamaTokenizer.from_pretrained(model_name)
model = LlamaModel.from_pretrained(model_name)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

target_prompt = "Write a poetic description of a sunset."

population_size = 20
mutation_rate = 0.1
max_generations = 50


def random_text():
    words = [
        "the",
        "a",
        "sunset",
        "sky",
        "beautiful",
        "red",
        "orange",
        "yellow",
        "clouds",
        "light",
    ]
    return " ".join(random.choice(words) for _ in range(10))


def fitness(text):
    inputs = tokenizer(text, return_tensors="pt", padding=True).to(device)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.logits.mean().item()


def mutate(text):
    words = text.split()
    if random.random() < mutation_rate:
        index = random.randint(0, len(words) - 1)
        words[index] = random_text().split()[random.randint(0, 9)]
    return " ".join(words)


population = [random_text() for _ in range(population_size)]
best_sample = max(population, key=fitness)
best_fitness = fitness(best_sample)

for generation in range(max_generations):
    fitness_scores = [fitness(sample) for sample in population]
    population = random.choices(population, weights=fitness_scores, k=population_size)
    population = [mutate(sample) for sample in population]
    current_best = max(population, key=fitness)
    current_fitness = fitness(current_best)
    if current_fitness > best_fitness:
        best_fitness = current_fitness
        best_sample = current_best
        print(f"Generation {generation}: {best_sample} (Fitness: {best_fitness})")

print(f"Best text after {max_generations} generations: {best_sample}")
