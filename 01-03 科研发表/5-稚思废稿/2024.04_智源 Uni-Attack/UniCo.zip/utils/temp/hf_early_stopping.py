from transformers import StoppingCriteria, StoppingCriteriaList


class MaxLengthCriteria(StoppingCriteria):
    def __init__(self, max_length):
        self.max_length = max_length

    def __call__(self, input_ids, scores):
        # Returns True when generation should stop, i.e., when the length reaches or exceeds max_length
        return input_ids.shape[-1] >= self.max_length


# Example usage
max_length_criteria = MaxLengthCriteria(max_length=50)
stopping_criteria_list = StoppingCriteriaList([max_length_criteria])

# In a generation call
from transformers import pipeline

generator = pipeline("text-generation", model="openai-community/gpt2")
generated_text = generator(
    "Once upon a time,", stopping_criteria=stopping_criteria_list
)

print(generated_text)
