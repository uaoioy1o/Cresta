# Load model directly
from transformers import AutoTokenizer, AutoModelForCausalLM

tokenizer = AutoTokenizer.from_pretrained("Locutusque/llama-3-neural-chat-v1-8b")

model = AutoModelForCausalLM.from_pretrained("Locutusque/llama-3-neural-chat-v1-8b")
