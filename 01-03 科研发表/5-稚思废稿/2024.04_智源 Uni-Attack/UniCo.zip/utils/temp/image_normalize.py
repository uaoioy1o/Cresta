from PIL import Image
import numpy as np
import torch

def normalize(images):
    """ Normalize the image tensor using predefined mean and std. """
    # Means and standard deviations for normalization
    mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).cuda()
    std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).cuda()
    
    # Normalize the images
    images = (images - mean[None, :, None, None]) / std[None, :, None, None]
    return images

# Load an image and ensure it is in RGB format
image_path = "image.png"
image = Image.open(image_path).convert('RGB')

# Convert the image to a numpy array, then to a torch tensor
image = np.array(image)
image = torch.tensor(image, dtype=torch.float32).permute(2, 0, 1).unsqueeze(0).cuda()

# Normalize the image tensor 100 times
for _ in range(100):
    image = normalize(image)

# Clip values to ensure they are within the typical range of image data
image = torch.clamp(image, 0, 255)

# Save the normalized image
image = image.squeeze(0).permute(1, 2, 0).cpu().detach().numpy().astype(np.uint8)
image = Image.fromarray(image)
image.save("normalized_image_100x.png")
