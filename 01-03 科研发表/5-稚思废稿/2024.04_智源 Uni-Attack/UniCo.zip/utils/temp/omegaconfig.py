import os

os.chdir(os.path.dirname(os.getcwd()))

from omegaconf import OmegaConf


def get_config():
    return OmegaConf.load("config/config.yaml")


def write_config(config):
    OmegaConf.save(config, "config/config.yaml")


conf = get_config()
conf.version = "0.1.0"
conf.corpus_path = "corpus/corpus.txt"
conf.log_file_path = "logs"
conf.cuda = True
conf.sentence_model_name = "all-MiniLM-L6-v2"

write_config(conf)
