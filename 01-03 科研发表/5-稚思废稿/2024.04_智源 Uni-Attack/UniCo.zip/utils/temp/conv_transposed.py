import torch
import torch.nn as nn

# 假设我们有一个单通道的 32x32 的图像
input_tensor = torch.randn(1, 1, 32, 32)  # 批大小为1，通道数为1

# 创建一个 ConvTranspose2d 层
# 参数依次是：输入通道数，输出通道数，卷积核大小，步长，填充
transpose_conv = nn.ConvTranspose2d(
    1, 1, kernel_size=3, stride=2, padding=1, output_padding=1
)

# 应用转置卷积层
output_tensor = transpose_conv(input_tensor)

print("输入尺寸:", input_tensor.shape)
print("输出尺寸:", output_tensor.shape)
