

当然，还有其他更复杂的对抗攻击方法。以下是几种常见的对抗攻击方法，它们比 HotFlip 方法更为复杂和强大：

1. **FGSM（Fast Gradient Sign Method）**：
    
    - 通过一次梯度更新生成对抗样本，通常用于图像数据。
    - 简单快速，但有时效果不如多步攻击。
    
    ```python
    import torch
    import torch.nn as nn
    import torch.optim as optim
    import torchvision
    import torchvision.transforms as transforms
    
    from torch.utils.data import DataLoader
    
    # 定义卷积神经网络
    class SimpleCNN(nn.Module):
        def __init__(self):
            super(SimpleCNN, self).__init__()
            self.conv1 = nn.Conv2d(1, 32, kernel_size=5)
            self.conv2 = nn.Conv2d(32, 64, kernel_size=5)
            self.fc1 = nn.Linear(1024, 128)
            self.fc2 = nn.Linear(128, 10)
    
        def forward(self, x):
            x = torch.relu(self.conv1(x))
            x = torch.max_pool2d(x, 2)
            x = torch.relu(self.conv2(x))
            x = torch.max_pool2d(x, 2)
            x = x.view(-1, 1024)
            x = torch.relu(self.fc1(x))
            x = self.fc2(x)
            return x
    
    # 定义FGSM攻击
    def fgsm_attack(image, epsilon, gradient):
        sign_gradient = gradient.sign()
        perturbed_image = image + epsilon * sign_gradient
        perturbed_image = torch.clamp(perturbed_image, 0, 1)
        return perturbed_image
    
    # 加载MNIST数据集
    transform = transforms.Compose([transforms.ToTensor()])
    train_dataset = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transform)
    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
    
    test_dataset = torchvision.datasets.MNIST(root='./data', train=False, download=True, transform=transform)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)
    
    # 定义设备、模型、损失函数和优化器
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SimpleCNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    # 训练模型
    def train(model, train_loader, criterion, optimizer, device, epochs=5):
        model.train()
        for epoch in range(epochs):
            for data, target in train_loader:
                data, target = data.to(device), target.to(device)
                optimizer.zero_grad()
                output = model(data)
                loss = criterion(output, target)
                loss.backward()
                optimizer.step()
            print(f"Epoch {epoch+1}, Loss: {loss.item()}")
    
    # 评估模型
    def test(model, test_loader, device, epsilon=0.3):
        model.eval()
        correct = 0
        adv_correct = 0
        total = 0
    
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            data.requires_grad = True
    
            output = model(data)
            _, pred = output.max(1)
            correct += (pred == target).sum().item()
    
            loss = criterion(output, target)
            model.zero_grad()
            loss.backward()
    
            gradient = data.grad.data
            perturbed_data = fgsm_attack(data, epsilon, gradient)
    
            adv_output = model(perturbed_data)
            _, adv_pred = adv_output.max(1)
            adv_correct += (adv_pred == target).sum().item()
    
            total += target.size(0)
    
        print(f"Test Accuracy = {correct / total * 100:.2f}%")
        print(f"Adversarial Test Accuracy = {adv_correct / total * 100:.2f}%")
    
    # 运行训练和测试
    train(model, train_loader, criterion, optimizer, device, epochs=5)
    test(model, test_loader, device, epsilon=0.3)
    ```
    
2. **PGD（Projected Gradient Descent）**：
    
    - 是 FGSM 的扩展，通过多步梯度更新生成对抗样本。
        
    - 每一步更新后将样本投影回合法域，通常效果较好。
        
        ```python
        import torch
        import torch.nn as nn
        import torch.optim as optim
        import torchvision
        import torchvision.transforms as transforms
        from torch.utils.data import DataLoader
        
        # 定义卷积神经网络
        class SimpleCNN(nn.Module):
            def __init__(self):
                super(SimpleCNN, self).__init__()
                self.conv1 = nn.Conv2d(1, 32, kernel_size=5)
                self.conv2 = nn.Conv2d(32, 64, kernel_size=5)
                self.fc1 = nn.Linear(1024, 128)
                self.fc2 = nn.Linear(128, 10)
        
            def forward(self, x):
                x = torch.relu(self.conv1(x))
                x = torch.max_pool2d(x, 2)
                x = torch.relu(self.conv2(x))
                x = torch.max_pool2d(x, 2)
                x = x.view(-1, 1024)
                x = torch.relu(self.fc1(x))
                x = self.fc2(x)
                return x
        
        # 定义PGD攻击
        def pgd_attack(model, images, labels, eps, alpha, iters):
            original_images = images.clone().detach()
            
            for i in range(iters):
                images.requires_grad = True
                outputs = model(images)
                
                model.zero_grad()
                loss = nn.CrossEntropyLoss()(outputs, labels)
                loss.backward()
                grad = images.grad.data
                
                images = images + alpha * grad.sign()
                eta = torch.clamp(images - original_images, min=-eps, max=eps)
                images = torch.clamp(original_images + eta, min=0, max=1).detach_()
            
            return images
        
        # 加载MNIST数据集
        transform = transforms.Compose([transforms.ToTensor()])
        train_dataset = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transform)
        train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
        
        test_dataset = torchvision.datasets.MNIST(root='./data', train=False, download=True, transform=transform)
        test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)
        
        # 定义设备、模型、损失函数和优化器
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = SimpleCNN().to(device)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)
        
        # 训练模型
        def train(model, train_loader, criterion, optimizer, device, epochs=5):
            model.train()
            for epoch in range(epochs):
                for data, target in train_loader:
                    data, target = data.to(device), target.to(device)
                    optimizer.zero_grad()
                    output = model(data)
                    loss = criterion(output, target)
                    loss.backward()
                    optimizer.step()
                print(f"Epoch {epoch+1}, Loss: {loss.item()}")
        
        # 评估模型
        def test(model, test_loader, device, eps=0.3, alpha=0.01, iters=40):
            model.eval()
            correct = 0
            adv_correct = 0
            total = 0
        
            for data, target in test_loader:
                data, target = data.to(device), target.to(device)
        
                # 测试正常样本
                output = model(data)
                _, pred = output.max(1)
                correct += (pred == target).sum().item()
        
                # 测试对抗样本
                perturbed_data = pgd_attack(model, data, target, eps, alpha, iters)
                adv_output = model(perturbed_data)
                _, adv_pred = adv_output.max(1)
                adv_correct += (adv_pred == target).sum().item()
        
                total += target.size(0)
        
            print(f"Test Accuracy = {correct / total * 100:.2f}%")
            print(f"Adversarial Test Accuracy = {adv_correct / total * 100:.2f}%")
        
        # 运行训练和测试
        train(model, train_loader, criterion, optimizer, device, epochs=5)
        test(model, test_loader, device, eps=0.3, alpha=0.01, iters=40)
        ```
        
3. **C&W（Carlini & Wagner）攻击**：
    
    - 通过优化目标函数生成对抗样本，通常针对特定模型定制，效果很好但计算复杂。
4. **DeepFool**：
    
    - 通过逐步线性化模型生成对抗样本，目的是最小化扰动幅度。

### 示例：PGD（Projected Gradient Descent）攻击

以下是一个基于 PyTorch 的 PGD 攻击实现：

```python
import torch
import torch.nn.functional as F

def pgd_attack(model, images, labels, epsilon=0.3, alpha=2/255, iters=40):
    """
    PGD攻击

    :param model: 目标模型
    :param images: 输入图像
    :param labels: 输入标签
    :param epsilon: 最大扰动幅度
    :param alpha: 每一步的步长
    :param iters: 迭代次数
    :return: 对抗样本
    """
    images = images.clone().detach().to(torch.device('cuda'))
    labels = labels.clone().detach().to(torch.device('cuda'))
    loss = torch.nn.CrossEntropyLoss()

    ori_images = images.data

    for i in range(iters) :
        images.requires_grad = True
        outputs = model(images)

        model.zero_grad()
        cost = loss(outputs, labels).to(torch.device('cuda'))
        cost.backward()

        adv_images = images + alpha * images.grad.sign()
        eta = torch.clamp(adv_images - ori_images, min=-epsilon, max=epsilon)
        images = torch.clamp(ori_images + eta, min=0, max=1).detach_()

    return images

# 示例用法
# 假设我们有一个模型和输入数据
model = ...  # 你的模型
images = ...  # 输入图像，形状为 (batch_size, channels, height, width)
labels = ...  # 输入标签，形状为 (batch_size)

# 生成对抗样本
adv_images = pgd_attack(model, images, labels)

# 使用对抗样本进行评估
model.eval()
with torch.no_grad():
    outputs = model(adv_images)
    _, pred = torch.max(outputs.data, 1)
    correct = (pred == labels).sum().item()

print(f'对抗攻击后的准确率: {correct / len(labels) * 100}%')

```

### 解释

- **`epsilon`**：最大扰动幅度，控制对抗样本与原始样本之间的距离。
- **`alpha`**：每一步的步长，控制每次更新的幅度。
- **`iters`**：迭代次数，决定生成对抗样本的步数。

### 方法步骤

1. **初始化**：将输入图像和标签拷贝到 GPU，并定义损失函数。
2. **迭代生成对抗样本**：
    - 每次迭代中，计算当前图像的梯度。
    - 根据梯度方向更新图像，生成对抗样本。
    - 将对抗样本限制在合法域内（如图像像素值范围为 [0, 1]）。
3. **返回对抗样本**：经过多步迭代后，返回生成的对抗样本。

### 其他攻击方法

除了 PGD 以外，还有其他一些流行的攻击方法：

- **DeepFool**：通过逐步线性化模型生成对抗样本，目的是最小化扰动幅度。DeepFool 的目标是找到使输入越过决策边界的最小扰动。
- **C&W（Carlini & Wagner）攻击**：通过优化目标函数生成对抗样本，通常针对特定模型定制，效果很好但计算复杂。C&W 攻击通过直接优化对抗样本，使其对模型的输出产生特定的变化。

这些方法各有优劣，可以根据具体应用场景选择合适的方法。

```python
class HotFlipExample:
    def __init__(self, vocab_to_id, embedding_matrix):
        self.vocab_to_id = vocab_to_id
        self.embedding_matrix = embedding_matrix

    def hotflip_attack(self, grad, token, increase_loss=False, num_candidates=1):
        token_id = self.vocab_to_id[token]
        print(token_id)
        token_emb = self.embedding_matrix[token_id]  # embedding of current token
        print(token_emb)
        print((self.embedding_matrix - token_emb))
        print((self.embedding_matrix - token_emb).shape)
        print(grad.shape)
        scores = ((self.embedding_matrix - token_emb) @ grad.T).squeeze(1)
        print(scores)
        if not increase_loss:
            scores *= -1  # lower versus increase the class probability.
        _, best_k_ids = torch.topk(scores, num_candidates)
        return best_k_ids.detach().cpu().numpy()

# 示例词汇表和嵌入矩阵
vocab_to_id = {'hello': 0, 'world': 1, 'foo': 2, 'bar': 3}
embedding_matrix = torch.tensor([
    [0.1, 0.2],
    [0.3, 0.4],
    [0.5, 0.6],
    [0.7, 0.8]
], dtype=torch.float32)

# 示例梯度
grad = torch.tensor([0.01, 0.02], dtype=torch.float32).unsqueeze(0)

# 创建实例并调用 hotflip_attack 方法
example = HotFlipExample(vocab_to_id, embedding_matrix)
best_k_ids = example.hotflip_attack(grad, 'hello', increase_loss=True, num_candidates=2)
print("最佳候选 token ID:", best_k_ids)

```