# UNiCo

## Corpus

1. Evil Text Copus
   corpus\base\derogatory_corpus.csv
   corpus\base\question_list.csv

2. JailBreak Text
   corpus\base\GPTFuzzer.csv
   corpus\base\seed_short_25.csv

## Contribution

贡献一 统一了开源的这些邪恶语料库吧？
贡献二 不仅统一了 还生成了对应的邪恶图片
贡献三 语料+图片 都能攻破 但我们可以进一步构建了一个强大的盾（Uni-filter）

## Step

1. 对 Visual-Adversarial-Examples-Jailbreak-Large-Language-Models-main 的 66 条 text 进行变异，生成 1000 条

   1. 尝试 1：
      基于 API 限制变异
   2. 尝试 2：
      基于 LLaMa3 无限制版本进行变异

2. 使用 Stable Diffusion 根据生成的 text 生成 image
   Possible：

   1. 跟 text 强相关，直接用 text 生成侮辱性的
      每个 text 对应一个 image
   2. 跟 text 弱相关，用一个类别对应生成 image
      每一类对应一个 image
      比如说，所有对应的侮辱黑人的，生成一张黑人的照片
      所有对应侮辱日本人的，生成一张日本人的照片

3. 用修改后的 text 和 image，重新跑 Visual-Adversarial-Examples-Jailbreak-Large-Language-Models-main 的代码

创新点 1： 1. 基于大模型进行文本变异 2. 图文辅助增强生成效果(或者叫 Co-Attack？)

# Copyright BAAI
