import os

os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import re
import csv
import torch
import random
import logging

import numpy as np

from typing import Optional

# from dotenv import load_dotenv

from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers import PegasusForConditionalGeneration, PegasusTokenizer

from sentence_transformers import SentenceTransformer, util


def setup_logging(log_file_path):
    if not os.path.exists(log_file_path):
        os.makedirs(log_file_path)
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
        handlers=[
            logging.FileHandler(os.path.join(log_file_path, "log.txt")),
            logging.StreamHandler(),
        ],
    )
    logging.info("Logging setup complete.")
    # for key, value in os.environ.items():
    #     logging.info(f"{key}: {value}")


def seed_everything(seed=1029):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


def load_model(model_name: str, device: Optional[str] = None):
    if not os.path.exists("./cache"):
        os.makedirs("./cache")
    tokenizer = AutoTokenizer.from_pretrained(model_name, cache_dir="./cache")
    model = AutoModelForCausalLM.from_pretrained(model_name, cache_dir="./cache")
    return tokenizer, model


def load_corpus(corpus_path: str):
    with open(corpus_path, "r") as f:
        corpus = f.readlines()
    for i in range(len(corpus)):
        corpus[i] = corpus[i].strip()
    return corpus


def call_neural_llama3(
    tokenizer,
    model,
    device,
    prompt: str,
    max_tokens: int = 150,
    temperature: float = 1.0,
) -> Optional[str]:
    input_ids = tokenizer.encode(prompt, return_tensors="pt").to(device)
    model.to(device)
    output = model.generate(input_ids, max_length=max_tokens, temperature=temperature)
    return tokenizer.decode(output[0], skip_special_tokens=True)


def call_pegasus(
    tokenizer,
    model,
    device,
    prompt: str,
    num_beams: int = 10,
    max_tokens: int = 150,
    temperature: float = 1.0,
    num_return_sequences: int = 2,
):
    logging.info("Prompt: {}".format(prompt))
    batch = tokenizer(
        [prompt],
        truncation=True,
        padding="longest",
        max_length=60,
        return_tensors="pt",
    ).to(device)
    model.to(device)
    translated = model.generate(
        **batch,
        max_length=60,
        num_beams=num_beams,
        num_return_sequences=num_return_sequences,
        temperature=1.5
    )
    tgt_text = tokenizer.batch_decode(translated, skip_special_tokens=True)
    return tgt_text[0]


def get_similarity(model, text1, text2):
    embeddings1 = model.encode(text1, convert_to_tensor=True)
    embeddings2 = model.encode(text2, convert_to_tensor=True)

    similarity = util.pytorch_cos_sim(embeddings1, embeddings2)

    return similarity.item()


def main():
    # load_dotenv()
    # conf = get_config()
    seed_everything(1029)
    setup_logging("log/mutator_offline")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    """
    需要使用未经审查的模型
    这种模型是通过相同方法重训，因此包含不当内容
    """
    # 一个可能的LLaMa3 8B模型:
    # "/share/project/liuaofan/ai_sec_research/llama-3-neural-chat-v1-8b"
    # tokenizer, model = load_model(
    #     "Locutusque/llama-3-neural-chat-v1-8b",
    # )

    # 另一个可能的Pegasus模型:
    model_name = "tuner007/pegasus_paraphrase"
    tokenizer = PegasusTokenizer.from_pretrained(model_name)
    model = PegasusForConditionalGeneration.from_pretrained(model_name).to(device)

    similarity_model = SentenceTransformer("all-MiniLM-L6-v2")
    similarity_model.to(device)

    # /share/project/liuaofan/ai_sec_research/UNiCo/corpus/base/derogatory_corpus.csv
    corpus = load_corpus("corpus/base/harmful/derogatory_corpus.csv")
    sentences = []
    paraphrased = []
    scores = []
    for epoch in range(10):
        for sentence in corpus:
            pattern = r'^"(.+?)",'
            match = re.match(pattern, sentence)
            if match:
                sentence = match.group(1)
                sentences.append(sentence)

            print("Original sentence: {}".format(sentence))
            logging.info("Original sentence: {}".format(sentence))
            output = call_pegasus(
                tokenizer,
                model,
                device=device,
                prompt=sentence,
            )
            print("Paraphrased sentence: {}".format(output))
            logging.info("Paraphrased sentence: {}".format(output))

            match = re.match(pattern, output)
            if match:
                output = match.group(1)
            paraphrased.append(output)
            scores.append(get_similarity(similarity_model, sentence, output))

        assert len(corpus) == len(paraphrased)
        assert len(paraphrased) == len(scores)

        logging.info("Epoch {} finished.".format(epoch))
        logging.info("Writing back to csv...")
        logging.info("corpus length: {}".format(len(corpus)))
        logging.info("paraphrased length: {}".format(len(paraphrased)))
        logging.info("scores length: {}".format(len(scores)))

        if not os.path.exists("corpus/variant"):
            os.makedirs("corpus/variant")
        # write back to csv
        with open("corpus/variant/derogatory_corpus_{}.csv".format(epoch), "a") as f:
            writer = csv.writer(f)
            for sentence, paraphrased_sentence, score in zip(
                sentences, paraphrased, scores
            ):
                writer.writerow([sentence, str(paraphrased_sentence), score])


if __name__ == "__main__":
    main()
