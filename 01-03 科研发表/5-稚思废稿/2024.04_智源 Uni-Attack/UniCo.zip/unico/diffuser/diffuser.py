import torch
from PIL import Image
from diffusers import DiffusionPipeline


def generate_image_with_diffusion(pipeline, text_description, save_path):
    try:
        pipeline.to("cuda")
        result = pipeline(text_description)
        result.images[0].save(save_path)
        print("Generated image saved successfully at:", save_path)
    except Exception as e:
        print("An error occurred:", e)


def main():
    pipeline = DiffusionPipeline.from_pretrained(
        "runwayml/stable-diffusion-v1-5", torch_dtype=torch.float16
    )
    text_description = "An image of a squirrel in Picasso style"
    save_path = "./generated_image.jpg"
    generate_image_with_diffusion(pipeline, text_description, save_path)


if __name__ == "__main__":
    main()
