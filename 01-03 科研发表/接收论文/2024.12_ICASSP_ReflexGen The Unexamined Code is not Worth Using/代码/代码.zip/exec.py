import os
import tempfile
import json
import yaml
import time
import subprocess
from tqdm import tqdm
from pathlib import Path
from threading import Lock
from concurrent.futures import ThreadPoolExecutor
from typing import Optional
from yamlize import Object, Attribute, StrList
from utils import set_args

# Get working directory
WORKING_DIR = Path(__file__).parent.parent

# program: str => Result
CACHE = dict()
CACHE_LOCK = Lock()


class Problem(Object):
    name = Attribute(type=str)
    language = Attribute(type=str)
    prompt = Attribute(type=str)
    tests = Attribute(type=str)
    completions = Attribute(type=list)
    stop_tokens = Attribute(type=StrList)
    # content = Attribute(type=str)
    # role = Attribute(type=str)


def eval_string_script(language, program):
    eval_script, file_ext = eval_script_python, ".py"
    with tempfile.NamedTemporaryFile(suffix=file_ext, delete=True) as f:
        f.write(program.encode("utf-8"))
        f.flush()
        result = eval_script(Path(f.name))
        # Only save the first 2K of output from the running program. Any futher
        # output is very likely an exceptionally long stack trace or a long
        # series of prints.
        if type(result["stdout"]) == bytes:
            result["stdout"] = result["stdout"].decode("utf-8", errors="ignore")
        if result["stdout"] is None:
            result["stdout"] = ""
        if result["stderr"] is None:
            result["stderr"] = ""
        if type(result["stderr"]) == bytes:
            result["stderr"] = result["stderr"].decode("utf-8", errors="ignore")
        assert type(result["stdout"]) == str
        assert type(result["stderr"]) == str
        return {
            "program": program,
            "stdout": result["stdout"].replace("!!int", "")[:2048],
            "stderr": result["stderr"][:2048],
            "exit_code": result["exit_code"],
            "status": result["status"],
        }


def eval_script_python(path: Path):
    output = None
    try:
        # Assumes exit-code 0 is all okay
        output = subprocess.run(
            ["python3", str(path)], encoding="utf-8", capture_output=True, timeout=5
        )
        returncode = -1
        if output.returncode == 0:
            status = "OK"
            returncode = output.returncode
        elif "SyntaxError" in output.stderr:
            status = "SyntaxError"
            returncode = output.returncode
        else:
            status = "Exception"
    except subprocess.TimeoutExpired as exc:
        status = "Timeout"
        returncode = -1
        output = exc

    return {
        "status": status,
        "exit_code": returncode,
        "stdout": str(output.stdout),
        "stderr": str(output.stderr),
    }


def cache_get(program: str) -> Optional[dict]:
    if program in CACHE:
        result = CACHE[program]
        return result
    else:
        return None


def cache_set(program: str, result: dict):
    if program in CACHE:
        print("Setting already-existing cache")
    CACHE[program] = result


def cached_eval_script(problem, index) -> dict:
    program = problem.prompt + problem.completions[index][0] + "\n" + problem.tests
    CACHE_LOCK.acquire(True)
    cached = cache_get(program)
    if cached is not None:
        CACHE_LOCK.release()
        return cached
    else:
        result_yaml = dict()
        cache_set(program, result_yaml)
        CACHE_LOCK.release()
        result_dict = eval_string_script(problem.language, program)
        for k in result_dict.keys():
            result_yaml[k] = result_dict[k]
            result_yaml["timestamp"] = int(time.time())
        return result_yaml


class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


def evaluate_problem_in_container(problem_yaml_path: Path, index):
    proc = subprocess.run(
        [
            "podman",
            "run",
            "--rm",
            "--volume",
            f"{WORKING_DIR}:/multipleval:rw",
            "--timeout",
            "30",
            "multipleval",
            "python3",
            "containerized_eval.py",
            "--problem_yaml_path",
            str(problem_yaml_path),
            "--index",
            str(index),
        ],
        capture_output=True,
        stdin=subprocess.DEVNULL,
    )
    if proc.returncode == 0:
        return proc.stdout.decode("utf-8")

    return json.dumps(
        {
            "exit_code": proc.returncode,
            "stdout": proc.stdout.decode("utf-8"),
            "stderr": proc.stderr.decode("utf-8"),
            "program": "",
            "status": "Container timeout",
        }
    )


def get_test_results_yaml_path(problem_yaml_path: Path) -> Path:
    return problem_yaml_path.parent / (problem_yaml_path.stem + ".results.yaml")


def evaluate_problem(problem_yaml_path: Path, max_workers: int):
    with open(problem_yaml_path) as f:
        problem = Problem.load(f)

    # Do not create a blank .results.yaml file if there are no completions ready.
    if len(problem.completions) == 0:
        print("len==0")
        return

    test_results_path = get_test_results_yaml_path(problem_yaml_path)

    if not test_results_path.exists():
        test_results = {
            "name": problem.name,
            "language": problem.language,
            "results": [],
        }
    else:
        with test_results_path.open() as f:
            test_results = yaml.safe_load(f)

    num_problems = len(problem.completions)

    if len(test_results["results"]) == num_problems:
        print("len==num_problems")
        return
    elif len(test_results["results"]) > num_problems:
        print(f"ERROR more results than completions for {problem_yaml_path}")
        return

    min_problem = len(test_results["results"])

    # In case we have previously computed results, warm the cache with them
    for already_computed in test_results["results"]:
        CACHE[already_computed["program"]] = already_computed

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        for j in executor.map(
            lambda index: cached_eval_script(problem, index),
            range(min_problem, num_problems),
        ):
            test_results["results"].append(j)
            with test_results_path.open("w") as f:
                f.write(yaml.dump(test_results, Dumper=NoAliasDumper))


def evaluate_problems(target_dir: Path, max_workers: int):
    problems = [
        p for p in target_dir.glob("*.yaml") if not p.name.endswith(".results.yaml")
    ]

    for problem_yaml_path in tqdm(problems, desc=str(target_dir)):
        evaluate_problem(problem_yaml_path, max_workers)


def exec_main():
    args = set_args()
    args.output_dir = os.path.join(args.output_dir, args.eval_type, args.llm_type)

    files = [
        p
        for p in Path(args.output_dir).glob("*.yaml")
        if not p.name.endswith(".results.yaml")
    ]
    for file in tqdm(files):
        evaluate_problem(file, args.max_workers)


if __name__ == "__main__":
    exec_main()
