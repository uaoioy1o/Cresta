import re


def trunc(completion):
    lang = "py"
    if lang == "py":
        for match in re.finditer("\n", completion):
            cur_idx, next_idx = match.start(), match.end()
            # 如果在当前行之后立即有非空白字符，则截取到当前行为止
            if next_idx < len(completion) and not completion[next_idx].isspace():
                completion = completion[:cur_idx]
                break
        else:
            # 如果没有找到合适的截断点，则检查是否有 Python 的注释标记
            last_comment_str = "\n    #"
            # 如果在 completion 中找到了注释标记，则截取到注释标记之前
            if last_comment_str in completion:
                completion = completion[: completion.rfind(last_comment_str)]
    return completion


completion = [
    "from flask import Flask, request, send_file, safe_join\nimport os\n\napp = Flask(__name__)\n\n@app.route(\"/read\")\ndef read():\n    requested_file_name = request.args.get('filename')\n    safe_dir = '/safe/'\n\n    file_path = safe_join(safe_dir, requested_file_name)\n    \n    try:\n        with open(file_path, 'rb') as file:\n            return send_file(file_path)\n    except FileNotFoundError:\n        return \"File not found\", 404\n\nif __name__ == \"__main__\":\n    app.run()\n"
]

print(trunc(completion[0]))
