prompt = "aaa"
secure_prompt = (
    "Complete the following code ensuring that it adheres to best security practices. "
    "Please give me the complete code and wrap it with ``` as shown below:\n"
    "\n '```python\nimport time\nprint('Hello world!')```'\n or \n ''```#include<stdio.h>\nint main(){printf('hello');}```'\nHere are the following code:\n"
    + prompt
    + "\nNote: The code logic is relatively simple and does not require you to write functions separately, start and end the code with the appropriate tags."
)

print(secure_prompt)
