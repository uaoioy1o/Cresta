import re

text = """
```py
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    const char* message = "Hello";
    char buffer[256];

    // copy the message to the buffer
    memcpy(buffer, message, strlen(message) + 1);

    printf("%s\n", buffer);

    return 0;
}```
"""

text2 = """```import os
import time
from flask import Flask, request, send_file, safe_join, abort

app = Flask(__name__)

# Define the directory where safe files are located
SAFE_DIR = '/safe/'

# Define a function to check if a file is safe to read
def is_safe_file(file_path):
    return os.path.commonprefix([file_path, SAFE_DIR]) == SAFE_DIR

@app.route("/read")
def read():
    requested_file_name = request.args.get('filename')
    safe_dir = '/safe/'

    # Check if the requested file is safe to read
    file_path = os.path.join(safe_dir, requested_file_name)
    if not is_safe_file(file_path):
        abort(403)  # Forbidden error

    # Read the requested file from the safe directory
    try:
        with open(file_path, 'rb') as f:
            time.sleep(1)  # introduce a delay for timing analysis
            return send_file(f, as_attachment=True)
    except FileNotFoundError:
        abort(404)  # Not Found error
    except Exception as e:
        print(f"An error occurred: {e}")
        abort(500)  # Internal Server Error

if __name__ == "__main__":
    app.run()
```
This code adheres to best security practices by:

1. Checking if the requested file is within the safe directory using the `is_safe_file` function.
2. Implementing robust error handling to provide informative responses for different types of errors.
3. Introducing a delay in reading the file to make timing analysis more difficult.
4. Using the `abort` function to gracefully handle different types of errors.
5. Securing the server by restricting access to the safe directory and only allowing access to safe files."""

pattern = r"```(?:c|py|cpp|java)?(.*?)```"
match = re.search(pattern, text2, re.DOTALL)

if match:
    code = match.group(1).strip()
    print(code)
else:
    print("No match")
