import os
import chromadb
import numpy as np

from typing import List
from dotenv import load_dotenv

from langchain import hub
from langchain_chroma import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.document_loaders import DirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter


def env_load():
    if os.path.exists(".env"):
        load_dotenv()


def embed_rag(input_text: str = None):
    persist_folder = "/root/.temp/sven-master/rag_sven/persisted"
    # persist_folder = (
    #     r"C:\\af.liu\\focus_center\\astro\\3-RAG-Sec\\code_gen\\rag_sven\\persisted"
    # )

    # Check if the directory is empty
    if not os.listdir(persist_folder):
        # code/rag_sven/data/CVE-2006-3635
        # code_gen\rag_sven\storage\model_codeqwen1.5_7b
        loader = DirectoryLoader(
            "/root/.temp/sven-master/rag_sven",
            glob="storage/model_codeqwen1.5_7b/*/*/*/completion.txt",
            show_progress=True,
            silent_errors=True,
        )
        docs = loader.load()

        length = len(docs)
        print(f"Loaded {length} documents")

        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000, chunk_overlap=200
        )
        splits = text_splitter.split_documents(docs)

        model_name = "sentence-transformers/all-mpnet-base-v2"
        model_kwargs = {"device": "cuda"}
        encode_kwargs = {"normalize_embeddings": False}
        hfEmbeddings = HuggingFaceEmbeddings(
            model_name=model_name,
            model_kwargs=model_kwargs,
            encode_kwargs=encode_kwargs,
        )

        vectorstore = Chroma.from_documents(
            documents=splits,
            embedding=hfEmbeddings,
            collection_name="langchain_store",
            persist_directory=persist_folder,
        )
    else:
        model_name = "sentence-transformers/all-mpnet-base-v2"
        model_kwargs = {"device": "cuda"}
        encode_kwargs = {"normalize_embeddings": False}
        hfEmbeddings = HuggingFaceEmbeddings(
            model_name=model_name,
            model_kwargs=model_kwargs,
            encode_kwargs=encode_kwargs,
        )

        client = chromadb.PersistentClient(path=persist_folder)
        vectorstore = Chroma(
            collection_name="langchain_store",
            embedding_function=hfEmbeddings,
            client=client,
        )

    retriever = vectorstore.as_retriever(search_kwargs={"k": 1})
    prompt = hub.pull("rlm/rag-prompt")

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    # Get the top 2 most relevant documents
    top_docs = retriever.get_relevant_documents(input_text)

    return format_docs(top_docs)


# Adapter from https://github.com/KMnO4-zx/TinyRAG/blob/master/RAG/Embeddings.py
class BaseEmbeddings:
    """
    Base class for embeddings
    """

    def __init__(self, path: str, is_api: bool) -> None:
        self.path = path
        self.is_api = is_api

    def get_embedding(self, text: str, model: str) -> List[float]:
        raise NotImplementedError

    @classmethod
    def cosine_similarity(cls, vector1: List[float], vector2: List[float]) -> float:
        """
        calculate cosine similarity between two vectors
        """
        dot_product = np.dot(vector1, vector2)
        magnitude = np.linalg.norm(vector1) * np.linalg.norm(vector2)
        if not magnitude:
            return 0
        return dot_product / magnitude


class OpenAIEmbedding(BaseEmbeddings):
    """
    class for OpenAI embeddings
    """

    def __init__(self, path: str = "", is_api: bool = True) -> None:
        super().__init__(path, is_api)
        if self.is_api:
            from openai import OpenAI

            self.client = OpenAI()
            self.client.api_key = os.getenv("OPENAI_API_KEY")
            self.client.base_url = os.getenv("OPENAI_BASE_URL")

    def get_embedding(
        self, text: str, model: str = "text-embedding-3-large"
    ) -> List[float]:
        if self.is_api:
            text = text.replace("\n", " ")
            return (
                self.client.embeddings.create(input=[text], model=model)
                .data[0]
                .embedding
            )
        else:
            raise NotImplementedError


class JinaEmbedding(BaseEmbeddings):
    """
    class for Jina embeddings
    """

    def __init__(
        self, path: str = "jinaai/jina-embeddings-v2-base-zh", is_api: bool = False
    ) -> None:
        super().__init__(path, is_api)
        self._model = self.load_model()

    def get_embedding(self, text: str) -> List[float]:
        return self._model.encode([text])[0].tolist()

    def load_model(self):
        import torch
        from transformers import AutoModel

        if torch.cuda.is_available():
            device = torch.device("cuda")
        else:
            device = torch.device("cpu")
        model = AutoModel.from_pretrained(self.path, trust_remote_code=True).to(device)
        return model


class ZhipuEmbedding(BaseEmbeddings):
    """
    class for Zhipu embeddings
    """

    def __init__(self, path: str = "", is_api: bool = True) -> None:
        super().__init__(path, is_api)
        if self.is_api:
            from zhipuai import ZhipuAI

            ZHIPUAI_API_KEY = os.getenv("ZHIPUAI_API_KEY")
            self.client = ZhipuAI(api_key=ZHIPUAI_API_KEY)

    def get_embedding(self, text: str) -> List[float]:
        response = self.client.embeddings.create(
            model="embedding-2",
            input=text,
        )
        return response.data[0].embedding


if __name__ == "__main__":
    text = """
@app.route("/read")
def read():
    requested_file_name = request.args.get('filename')
    safe_dir = '/safe/'

    # read the requested file from the safe directory
"""
    print(embed_rag(text))
