import os
from pathlib import Path
from tqdm import tqdm
from yamlize import Object, Attribute, Sequence, StrList, Typed

from utils import (
    set_seed,
    set_logging,
    set_devices,
    Message,
    trim_code,
    extract_python_code,
    chat_with_chatanywhere,
    set_args,
)


class Bcolors:
    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


def print_warning(msg):
    print(f"{Bcolors.WARNING}{msg}{Bcolors.ENDC}")


def print_input(msg):
    print(f"{Bcolors.OKGREEN}{msg}{Bcolors.ENDC}")


def print_info(msg):
    print(f"{Bcolors.OKBLUE}{msg}{Bcolors.ENDC}")


def print_success(msg):
    print(f"{Bcolors.OKGREEN}{msg}{Bcolors.ENDC}")


def print_fail(msg):
    print(f"{Bcolors.FAIL}{msg}{Bcolors.ENDC}")


class Problem(Object):
    name = Attribute(type=str)
    language = Attribute(type=str)
    prompt = Attribute(type=str)
    tests = Attribute(type=str)
    completions = Attribute(type=list)
    stop_tokens = Attribute(type=StrList)
    # content = Attribute(type=str)
    # role = Attribute(type=str)


def generation_main():
    LANGUAGE = "python"
    EXTENTION = ".py"
    EMPHASIS = (
        f"You are a helpful assistant that generates {LANGUAGE} code per request. Your output only includes executable source code. "
        'All the explanation or description or "```" in the output shoule be prohibited.Specific needs are as follows\n'
    )
    api_key = "sk-Htdev0KgVYIlmbW6jPeCyd50bl4FLh6rldp0ryjVU5e0U7k3"
    args = set_args(EMPHASIS)
    set_logging(args, None)
    set_devices(args)
    set_seed(args)
    input_dir = Path(os.path.join(args.input_dir, args.eval_type))
    problems = list(
        filter(
            lambda f: not f.name.endswith(".results.yaml"),
            sorted(input_dir.glob("*.yaml")),
        )
    )
    for problem_yaml_path in tqdm(problems):
        with problem_yaml_path.open() as f:
            problem = Problem.load(f)
        prompt = [Message(content=problem.prompt, role="user")]
        for i in range(args.num_samples // args.num_samples_per_gen):
            set_seed(args)
            for j in range(args.num_samples_per_gen):
                response = chat_with_chatanywhere(
                    api_key,
                    args.llm_type,
                    prompt,
                )
                completion = [
                    extract_python_code(response)
                ]  # 假设API响应只包含一个有效的消息
                args.seed += 1
                completion = trim_code(completion, problem.stop_tokens)
                problem.completions.append(list(completion))  # 将生成的代码添加到问题中
        save_file_path = os.path.abspath(
            os.path.join(
                args.output_dir,
                args.eval_type,
                args.llm_type,
                os.path.basename(problem_yaml_path),
            )
        )
        os.makedirs(os.path.dirname(save_file_path), exist_ok=True)
        # 在尝试写入文件之前，确保目录存在
        with open(save_file_path, "w") as f:
            f.write(Problem.dump(problem))


if __name__ == "__main__":
    generation_main()
