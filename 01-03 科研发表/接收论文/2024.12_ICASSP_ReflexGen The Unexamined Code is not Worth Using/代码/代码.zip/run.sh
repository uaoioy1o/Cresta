clear

## Step0 Set the experiment name
# conda activate azureml_py310_sdkv2

tag1="gpt35-turbo"
tag2="gpt4o"
tag3="qwen1.5code"
tag4="llama7b"
tag5="gemini1.0-pro"
TAG=$tag3

DATETIME=$(date "+%Y%m%d_%H%M%S_")
EXP_NAME=${DATETIME}${TAG}


## Step1 Configure the environment
### 配置环境变量

# pip install langchain
# pip install langchainhub
# pip install langchain-chroma
# pip install langchain-community
# pip install langchain-text-splitters
# pip install unstructured
# pip install sentence-transformers
# pip install google-generativeai
# pip install sentence-transformers



## Step2 Completion the Code
### 根据需要的模型，修改对应的模型地址

# cd ../completion
# python batch_completion_4o.py

### then copy the generated data to the corresponding path in the current directory
### we leave this manual step here for now, as the data sometimes need to be modified manually



## Step3 Generate LangChain Persist from HF model
### 需要修改为对应的 storage 模型地址

# rm -rf ./persisted
# HF_ENDPOINT=https://hf-mirror.com python embeddings.py



## Step4 Run RAG-Sequence
### 需要修改代码中的参数
### 例如 API Key， Model Path etc.

rm -rf /root/.temp/sven-master/rag_sven/experiments/*
mkdir -p exps
HF_ENDPOINT=https://hf-mirror.com python security.py 2>&1 | tee exps/${EXP_NAME}.log